<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\User;
use App\Services\Profile\ProfileService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class ProfileController extends Controller
{
    public function __construct(
        protected ProfileService $profileService
    ) {}

    /**
     * Menampilkan halaman Lengkapi Profil
     */
    public function edit(): View
    {
        abort_unless(session()->has('activated_device_id'), 403);

        return view('profile.edit');
    }

    /**
     * Menyimpan akun baru setelah aktivasi device
     */
    public function store(ProfileUpdateRequest $request): RedirectResponse
    {
        abort_unless(session()->has('activated_device_id'), 403);

        $user = $this->profileService->createUser(
            $request->validated(),
            session('activated_device_id')
        );

        Auth::login($user);

        session()->forget('activated_device_id');

        return redirect()->route('vehicles.create');
    }

    /**
     * Update profil setelah user login
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
    {
        $user = Auth::user();

        assert($user instanceof User);

        $this->profileService->update(
            $user,
            $request->validated()
        );

        return back()->with(
            'success',
            'Profil berhasil diperbarui.'
        );
    }

    /**
     * Hapus akun
     */
    public function destroy(): RedirectResponse
    {
        $user = Auth::user();

        if ($user instanceof User) {
            Auth::logout();

            $user->delete();

            request()->session()->invalidate();
            request()->session()->regenerateToken();
        }

        return redirect()->route('login');
    }
}



<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="h-screen overflow-hidden bg-[#F8FAFC]">

    <div class="flex h-full">

        
        <?php echo $__env->make('home.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="relative z-10 flex flex-1 flex-col">

            
            <?php echo $__env->make('home.partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <main class="relative flex-1 min-h-0 overflow-hidden">

                <?php echo $__env->make('home.partials.map', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </main>

        </div>

    </div>

</div>


<?php if (isset($component)) { $__componentOriginal7cfab914afdd05940201ca0b2cbc009b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7cfab914afdd05940201ca0b2cbc009b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.toast','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7cfab914afdd05940201ca0b2cbc009b)): ?>
<?php $attributes = $__attributesOriginal7cfab914afdd05940201ca0b2cbc009b; ?>
<?php unset($__attributesOriginal7cfab914afdd05940201ca0b2cbc009b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7cfab914afdd05940201ca0b2cbc009b)): ?>
<?php $component = $__componentOriginal7cfab914afdd05940201ca0b2cbc009b; ?>
<?php unset($__componentOriginal7cfab914afdd05940201ca0b2cbc009b); ?>
<?php endif; ?>

<?php echo $__env->make('home.modals.add-geofence', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('home.modals.activate-device', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php echo $__env->make('home.modals.vehicle-information', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>

<link
    rel="stylesheet"
    href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>

<link
    rel="stylesheet"
    href="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css"/>

<style>

html,
body{
    height:100%;
}

#map{
    position:absolute;
    inset:0;
    width:100%;
    height:100%;
}

.leaflet-container{
    width:100%;
    height:100%;
}

.leaflet-control-attribution{
    display:none;
}

.leaflet-popup-content-wrapper{
    border-radius:14px;
}
/* ===========================================
| Layer Button
=========================================== */

.gps-layer-control{
    box-shadow:none !important;
    background:transparent !important;
    border:none !important;
}

.gps-layer-control .leaflet-control-layers-toggle{

    width:70px !important;

    height:70px !important;

    background-size:cover !important;

    border-radius:18px;

    background-image:url('/images/map-layer.png');

}

.gps-layer-control.leaflet-control-layers-expanded{

    background:white;

    border-radius:18px;

    padding:10px;

    box-shadow:0 15px 40px rgba(0,0,0,.18);

}

/* posisi */

.leaflet-bottom.leaflet-right{

    display:flex;

    flex-direction:column;

    align-items:flex-end;

}

.leaflet-control-zoom{

    margin-bottom:10px !important;

}

.gps-layer-control{

    margin-bottom:18px !important;

}

.leaflet-bottom.leaflet-right{

    bottom:120px !important;

    right:16px !important;

}

.leaflet-control-zoom{

    margin:0 !important;

}


</style>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<script src="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js"></script>

<?php echo $__env->make('home.partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\af-gps-tracker\resources\views/home/index.blade.php ENDPATH**/ ?>
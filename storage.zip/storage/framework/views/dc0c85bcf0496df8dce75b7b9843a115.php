<div
    id="vehicleInformationModal"
    class="fixed inset-0 z-[99999] hidden items-center justify-center bg-slate-900/60 backdrop-blur-sm">

    <div class="w-full max-w-xl rounded-3xl bg-white shadow-2xl">

        <div class="border-b border-slate-200 px-8 py-6">

            <h2 class="text-2xl font-bold">

                Informasi Kendaraan

            </h2>

            <p class="mt-1 text-sm text-slate-500">

                Lengkapi data kendaraan.

            </p>

        </div>

        <form
            id="vehicleInformationForm"
            class="space-y-6 p-8">

            <div>

                <label class="mb-2 block text-sm font-semibold">

                    Nama Kendaraan

                </label>

                <input
                    name="vehicle_name"
                    class="w-full rounded-xl border border-slate-300 px-4 py-3">

            </div>

            <div>

                <label class="mb-2 block text-sm font-semibold">

                    Plat Nomor

                </label>

                <input
                    name="plate_number"
                    class="w-full rounded-xl border border-slate-300 px-4 py-3 uppercase">

            </div>

            <div>

                <label class="mb-2 block text-sm font-semibold">

                    Jenis Kendaraan

                </label>

                <select
                    name="vehicle_type"
                    class="w-full rounded-xl border border-slate-300 px-4 py-3">

                    <option value="motor">
                        🏍 Motor
                    </option>

                    <option value="mobil">
                        🚗 Mobil
                    </option>

                    <option value="pickup">
                        🛻 Pickup
                    </option>

                    <option value="truck">
                        🚚 Truk
                    </option>

                    <option value="bus">
                        🚌 Bus
                    </option>

                    <option value="van">
                        🚐 Van
                    </option>

                    <option value="taxi">
                        🚕 Taxi
                    </option>

                    <option value="ambulance">
                        🚑 Ambulance
                    </option>

                    <option value="police">
                        🚓 Polisi
                    </option>

                    <option value="bicycle">
                        🚲 Sepeda
                    </option>

                </select>

            </div>

            <div>

                <label class="mb-2 block text-sm font-semibold">

                    Icon Marker

                </label>

                <select
                    name="marker_icon"
                    class="w-full rounded-xl border border-slate-300 px-4 py-3">

                    <option value="car">
                        🚗 Mobil
                    </option>

                    <option value="motorcycle">
                        🏍 Motor
                    </option>

                    <option value="pickup">
                        🛻 Pickup
                    </option>

                    <option value="truck">
                        🚚 Truk
                    </option>

                    <option value="bus">
                        🚌 Bus
                    </option>

                    <option value="van">
                        🚐 Van
                    </option>

                    <option value="taxi">
                        🚕 Taxi
                    </option>

                    <option value="ambulance">
                        🚑 Ambulance
                    </option>

                    <option value="police">
                        🚓 Polisi
                    </option>

                    <option value="bicycle">
                        🚲 Sepeda
                    </option>

                </select>

            </div>

            <div>

                <label class="mb-2 block text-sm font-semibold">

                    Warna Marker

                </label>

                <select
                    name="marker_color"
                    class="w-full rounded-xl border border-slate-300 px-4 py-3">

                    <option value="green">
                        🟢 Hijau
                    </option>

                    <option value="blue">
                        🔵 Biru
                    </option>

                    <option value="red">
                        🔴 Merah
                    </option>

                    <option value="orange">
                        🟠 Orange
                    </option>

                    <option value="yellow">
                        🟡 Kuning
                    </option>

                    <option value="purple">
                        🟣 Ungu
                    </option>

                    <option value="black">
                        ⚫ Hitam
                    </option>

                    <option value="gray">
                        ⚪ Abu-abu
                    </option>

                </select>

            </div>

            <div class="flex justify-end gap-3">

                <button
                    id="cancelVehicleInformation"
                    type="button"
                    class="rounded-xl border border-slate-300 px-6 py-3">

                    Batal

                </button>

                <button
                    type="submit"
                    class="rounded-xl bg-[#2563EB] px-6 py-3 font-semibold text-white">

                    Simpan Kendaraan

                </button>

            </div>

        </form>

    </div>

</div><?php /**PATH C:\laragon\www\af-gps-tracker\resources\views/home/modals/vehicle-information.blade.php ENDPATH**/ ?>